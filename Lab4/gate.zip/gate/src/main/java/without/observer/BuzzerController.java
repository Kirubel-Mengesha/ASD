package without.observer;

public class BuzzerController {
    public void start(){
        System.out.println("The buzzer is buzzing");
    }

    public void stop() {
        System.out.println("The buzzer has stopped");
    }
}
