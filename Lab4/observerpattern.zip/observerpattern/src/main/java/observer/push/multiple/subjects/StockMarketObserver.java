package observer.push.multiple.subjects;

public interface StockMarketObserver {
  public void update(boolean stockMarketOpen);
}
